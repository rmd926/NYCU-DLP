from .VQGAN import VQGAN
from .modules import Discriminator